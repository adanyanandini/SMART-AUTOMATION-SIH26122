let projects = [];
let currentProjectId = null;

const $ = (id) => document.getElementById(id);

async function api(url, options = {}) {
  const res = await fetch(url, {
    headers: { "Content-Type": "application/json" },
    ...options
  });
  const data = await res.json();
  if (!res.ok) throw new Error(data.error || "Request failed");
  return data;
}

function toast(message) {
  const el = $("toast");
  el.textContent = message;
  el.classList.add("toast-show");
  setTimeout(() => el.classList.remove("toast-show"), 2200);
}

function showPage(page) {
  document.querySelectorAll(".page").forEach(x => x.classList.remove("active"));
  document.querySelectorAll(".nav-btn").forEach(x => x.classList.remove("active"));
  $(page).classList.add("active");
  document.querySelector(`.nav-btn[data-page="${page}"]`)?.classList.add("active");
  if (page === "reports") renderReport();
}

async function loadAll(showMessage = false) {
  try {
    projects = await api("/api/projects");
    const stats = await api("/api/stats");
    renderDashboard(stats);
    renderProjects();
    renderSchedule();
    if ($("reports").classList.contains("active")) renderReport();
    $("statusDot").style.background = "#36b66f";
    $("serverText").textContent = "Live";
    if (showMessage) toast("Data refreshed");
  } catch (err) {
    $("statusDot").style.background = "#e05a5a";
    $("serverText").textContent = "Offline";
  }
}

function renderDashboard(stats) {
  $("statProjects").textContent = stats.projects;
  $("statProgress").textContent = stats.averageProgress + "%";
  $("statDelayed").textContent = stats.delayed;
  $("statTasks").textContent = `${stats.completedTasks} / ${stats.tasks}`;

  $("projectProgressList").innerHTML = projects.length ? projects.map(p => `
    <div class="progress-row">
      <div class="row-top"><span>${escapeHtml(p.name)}</span><span>${p.progress}%</span></div>
      <div class="bar"><i style="width:${p.progress}%"></i></div>
      <div class="meta">${escapeHtml(p.location)} • ${escapeHtml(p.status)} • Manager: ${escapeHtml(p.manager)}</div>
    </div>
  `).join("") : "<p>No projects yet.</p>";

  const activities = [...projects]
    .sort((a,b) => new Date(b.updatedAt) - new Date(a.updatedAt))
    .slice(0, 6);

  $("activityList").innerHTML = activities.length ? activities.map(p => `
    <div class="activity">
      <b>${escapeHtml(p.name)}</b> updated to <b>${p.progress}%</b>
      <small>${new Date(p.updatedAt).toLocaleString()}</small>
    </div>
  `).join("") : "<p>No activity.</p>";
}

function renderProjects() {
  const q = $("projectSearch").value.toLowerCase();
  const list = projects.filter(p =>
    p.name.toLowerCase().includes(q) || p.location.toLowerCase().includes(q) || p.manager.toLowerCase().includes(q)
  );

  $("projectGrid").innerHTML = list.length ? list.map(p => `
    <div class="project-card">
      <span class="badge ${p.status === "Delayed" ? "delayed" : p.status === "Completed" ? "completed" : "on-track"}">${p.status}</span>
      <h3>${escapeHtml(p.name)}</h3>
      <p>📍 ${escapeHtml(p.location)}</p>
      <p>👤 ${escapeHtml(p.manager)}</p>
      <p>📅 ${p.plannedStart} → ${p.plannedEnd}</p>
      <div class="bar"><i style="width:${p.progress}%"></i></div>
      <div class="meta">${p.progress}% complete • ${p.tasks.length} tasks</div>
      <div class="project-actions">
        <button class="open" onclick="openDetails(${p.id})">Open</button>
        <button onclick="deleteProject(${p.id})">Delete</button>
      </div>
    </div>
  `).join("") : "<div class='panel'><p>No matching projects.</p></div>";
}

function renderSchedule() {
  const rows = [];
  projects.forEach(p => {
    (p.tasks || []).forEach(t => {
      rows.push(`
        <tr>
          <td>${escapeHtml(p.name)}</td>
          <td>${escapeHtml(t.name)}</td>
          <td>${t.planned}</td>
          <td>${t.actual || "-"}</td>
          <td><span class="badge ${t.status === "Completed" ? "completed" : t.status === "In Progress" ? "on-track" : "delayed"}">${t.status}</span></td>
          <td>
            ${t.status !== "Completed"
              ? `<button class="secondary" onclick="completeTask(${p.id},${t.id})">Mark Done</button>`
              : "✓ Done"}
          </td>
        </tr>
      `);
    });
  });
  $("scheduleBody").innerHTML = rows.length ? rows.join("") : `<tr><td colspan="6">No tasks available.</td></tr>`;
}

function renderReport() {
  const total = projects.length;
  const delayed = projects.filter(p => p.status === "Delayed").length;
  const completed = projects.filter(p => p.status === "Completed").length;
  const avg = total ? Math.round(projects.reduce((s,p) => s + p.progress, 0) / total) : 0;
  const tasks = projects.flatMap(p => p.tasks || []);
  const done = tasks.filter(t => t.status === "Completed").length;

  $("reportBox").innerHTML = `
    <h3>Infrastructure Execution Summary</h3>
    <div class="report-line"><span>Total projects</span><b>${total}</b></div>
    <div class="report-line"><span>Average progress</span><b>${avg}%</b></div>
    <div class="report-line"><span>Delayed projects</span><b>${delayed}</b></div>
    <div class="report-line"><span>Completed projects</span><b>${completed}</b></div>
    <div class="report-line"><span>Completed tasks</span><b>${done} / ${tasks.length}</b></div>
    <p style="margin-top:15px;color:#6a7483">This report is generated directly from the application's JSON data store.</p>
  `;
}

async function openDetails(id) {
  currentProjectId = id;
  const p = projects.find(x => x.id === id);
  if (!p) return;

  $("detailsTitle").textContent = p.name;
  $("detailsContent").innerHTML = `
    <p>${escapeHtml(p.location)} • Manager: ${escapeHtml(p.manager)}</p>
    <div class="detail-progress">${p.progress}%</div>
    <div class="bar"><i style="width:${p.progress}%"></i></div>

    <div class="detail-actions" style="margin-top:18px">
      <label>Update progress (%)
        <input id="progressInput" type="number" min="0" max="100" value="${p.progress}">
      </label>
      <button class="primary" onclick="updateProgress()">Save Progress</button>
    </div>

    <div class="task-list">
      <h3>Tasks</h3>
      ${(p.tasks || []).map(t => `
        <div class="task-item">
          <span><b>${escapeHtml(t.name)}</b><br><small>Planned: ${t.planned}</small></span>
          <span>${t.actual ? "Actual: " + t.actual : "Not completed"}</span>
          ${t.status === "Completed" ? "<b>✓ Completed</b>" : `<button class="secondary" onclick="completeTask(${p.id},${t.id},true)">Mark Done</button>`}
        </div>
      `).join("")}
    </div>

    <form id="taskForm" style="margin-top:20px">
      <h3 style="margin-bottom:10px">Add Task</h3>
      <div class="form-grid">
        <label>Task Name<input name="name" required placeholder="e.g. Material inspection"></label>
        <label>Planned Date<input name="planned" type="date" required></label>
      </div>
      <button class="secondary" type="submit">+ Add Task</button>
    </form>
  `;

  $("taskForm").addEventListener("submit", addTask);
  $("detailsModal").classList.remove("hidden");
}

async function updateProgress() {
  try {
    const value = Number($("progressInput").value);
    await api(`/api/projects/${currentProjectId}/progress`, {
      method: "PATCH",
      body: JSON.stringify({ progress: value })
    });
    toast("Progress updated");
    $("detailsModal").classList.add("hidden");
    await loadAll();
  } catch (e) { toast(e.message); }
}

async function addTask(e) {
  e.preventDefault();
  const fd = new FormData(e.target);
  try {
    await api(`/api/projects/${currentProjectId}/tasks`, {
      method: "POST",
      body: JSON.stringify({
        name: fd.get("name"),
        planned: fd.get("planned")
      })
    });
    toast("Task added");
    await loadAll();
    openDetails(currentProjectId);
  } catch (e) { toast(e.message); }
}

async function completeTask(projectId, taskId, stayOpen = false) {
  try {
    await api(`/api/projects/${projectId}/tasks/${taskId}`, {
      method: "PATCH",
      body: JSON.stringify({
        status: "Completed",
        actual: new Date().toISOString().slice(0, 10)
      })
    });
    toast("Task marked completed");
    await loadAll();
    if (stayOpen) openDetails(projectId);
  } catch (e) { toast(e.message); }
}

async function deleteProject(id) {
  const p = projects.find(x => x.id === id);
  if (!p || !confirm(`Delete "${p.name}"?`)) return;

  try {
    await api(`/api/projects/${id}`, { method: "DELETE" });
    toast("Project deleted");
    await loadAll();
  } catch (e) { toast(e.message); }
}

$("projectForm").addEventListener("submit", async (e) => {
  e.preventDefault();
  const fd = new FormData(e.target);

  try {
    await api("/api/projects", {
      method: "POST",
      body: JSON.stringify({
        name: fd.get("name"),
        location: fd.get("location"),
        manager: fd.get("manager"),
        plannedStart: fd.get("plannedStart"),
        plannedEnd: fd.get("plannedEnd")
      })
    });
    e.target.reset();
    $("projectModal").classList.add("hidden");
    toast("Project created");
    await loadAll();
    showPage("projects");
  } catch (err) { toast(err.message); }
});

document.querySelectorAll(".nav-btn").forEach(btn => {
  btn.addEventListener("click", () => showPage(btn.dataset.page));
});

$("addProjectBtn").addEventListener("click", () => $("projectModal").classList.remove("hidden"));
$("refreshBtn").addEventListener("click", () => loadAll(true));
$("projectSearch").addEventListener("input", renderProjects);

document.querySelectorAll("[data-close]").forEach(btn => {
  btn.addEventListener("click", () => $(btn.dataset.close).classList.add("hidden"));
});

document.querySelectorAll(".modal").forEach(modal => {
  modal.addEventListener("click", e => {
    if (e.target === modal) modal.classList.add("hidden");
  });
});

$("downloadReportBtn").addEventListener("click", () => {
  const lines = [
    "INFRA TRACK - SIH26122 REPORT",
    "Generated: " + new Date().toLocaleString(),
    "",
    ...projects.map(p => `${p.name} | ${p.location} | ${p.status} | ${p.progress}% | ${p.plannedStart} to ${p.plannedEnd}`)
  ];
  const blob = new Blob([lines.join("\n")], { type: "text/plain" });
  const url = URL.createObjectURL(blob);
  const a = document.createElement("a");
  a.href = url;
  a.download = "InfraTrack_Report.txt";
  a.click();
  URL.revokeObjectURL(url);
  toast("Report downloaded");
});

function escapeHtml(value) {
  return String(value)
    .replaceAll("&", "&amp;")
    .replaceAll("<", "&lt;")
    .replaceAll(">", "&gt;")
    .replaceAll('"', "&quot;")
    .replaceAll("'", "&#039;");
}

function updateClock() {
  $("clock").textContent = new Date().toLocaleTimeString();
}
setInterval(updateClock, 1000);
updateClock();

loadAll();
setInterval(() => loadAll(), 3000);

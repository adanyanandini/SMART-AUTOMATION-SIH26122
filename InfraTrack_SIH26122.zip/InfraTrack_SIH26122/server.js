const express = require("express");
const fs = require("fs");
const path = require("path");

const app = express();
const PORT = 3000;
const DATA_DIR = path.join(__dirname, "data");
const DATA_FILE = path.join(DATA_DIR, "projects.json");

app.use(express.json());
app.use(express.static(path.join(__dirname, "public")));

function ensureData() {
  if (!fs.existsSync(DATA_DIR)) fs.mkdirSync(DATA_DIR);
  if (!fs.existsSync(DATA_FILE)) {
    const sample = [
      {
        id: 1,
        name: "City Flyover Construction",
        location: "Hyderabad",
        manager: "Ravi Kumar",
        status: "On Track",
        progress: 68,
        plannedStart: "2026-09-01",
        plannedEnd: "2026-12-20",
        actualStart: "2026-09-02",
        notes: "Main structure and pillars are progressing normally.",
        tasks: [
          { id: 101, name: "Foundation", planned: "2026-09-20", actual: "2026-09-18", status: "Completed" },
          { id: 102, name: "Pillars", planned: "2026-10-15", actual: "", status: "In Progress" },
          { id: 103, name: "Deck Slab", planned: "2026-11-15", actual: "", status: "Pending" }
        ],
        updatedAt: new Date().toISOString()
      },
      {
        id: 2,
        name: "Water Pipeline Project",
        location: "Warangal",
        manager: "Anita Sharma",
        status: "Delayed",
        progress: 42,
        plannedStart: "2026-08-20",
        plannedEnd: "2026-11-30",
        actualStart: "2026-08-25",
        notes: "Material delivery caused a schedule delay.",
        tasks: [
          { id: 201, name: "Survey", planned: "2026-09-05", actual: "2026-09-04", status: "Completed" },
          { id: 202, name: "Pipe Laying", planned: "2026-10-20", actual: "", status: "In Progress" }
        ],
        updatedAt: new Date().toISOString()
      }
    ];
    fs.writeFileSync(DATA_FILE, JSON.stringify(sample, null, 2));
  }
}

function readProjects() {
  ensureData();
  return JSON.parse(fs.readFileSync(DATA_FILE, "utf8"));
}

function saveProjects(projects) {
  fs.writeFileSync(DATA_FILE, JSON.stringify(projects, null, 2));
}

function nextId(items) {
  return items.length ? Math.max(...items.map(x => Number(x.id))) + 1 : 1;
}

app.get("/api/projects", (req, res) => {
  res.json(readProjects());
});

app.get("/api/projects/:id", (req, res) => {
  const project = readProjects().find(p => p.id === Number(req.params.id));
  if (!project) return res.status(404).json({ error: "Project not found" });
  res.json(project);
});

app.post("/api/projects", (req, res) => {
  const { name, location, manager, plannedStart, plannedEnd } = req.body;
  if (!name || !location || !manager || !plannedStart || !plannedEnd) {
    return res.status(400).json({ error: "Please fill all required fields." });
  }

  const projects = readProjects();
  const project = {
    id: nextId(projects),
    name,
    location,
    manager,
    status: "On Track",
    progress: 0,
    plannedStart,
    plannedEnd,
    actualStart: new Date().toISOString().slice(0, 10),
    notes: "New project created.",
    tasks: [],
    updatedAt: new Date().toISOString()
  };

  projects.push(project);
  saveProjects(projects);
  res.status(201).json(project);
});

app.patch("/api/projects/:id/progress", (req, res) => {
  const projects = readProjects();
  const project = projects.find(p => p.id === Number(req.params.id));
  if (!project) return res.status(404).json({ error: "Project not found" });

  let progress = Number(req.body.progress);
  if (Number.isNaN(progress)) return res.status(400).json({ error: "Progress must be a number." });
  progress = Math.max(0, Math.min(100, progress));

  project.progress = progress;
  project.status = progress >= 100 ? "Completed" : progress < 50 ? "Delayed" : "On Track";
  project.updatedAt = new Date().toISOString();
  saveProjects(projects);

  res.json(project);
});

app.post("/api/projects/:id/tasks", (req, res) => {
  const { name, planned } = req.body;
  if (!name || !planned) return res.status(400).json({ error: "Task name and planned date are required." });

  const projects = readProjects();
  const project = projects.find(p => p.id === Number(req.params.id));
  if (!project) return res.status(404).json({ error: "Project not found" });

  const allTasks = projects.flatMap(p => p.tasks || []);
  const task = {
    id: nextId(allTasks),
    name,
    planned,
    actual: "",
    status: "Pending"
  };

  project.tasks.push(task);
  project.updatedAt = new Date().toISOString();
  saveProjects(projects);
  res.status(201).json(task);
});

app.patch("/api/projects/:projectId/tasks/:taskId", (req, res) => {
  const projects = readProjects();
  const project = projects.find(p => p.id === Number(req.params.projectId));
  if (!project) return res.status(404).json({ error: "Project not found" });

  const task = (project.tasks || []).find(t => t.id === Number(req.params.taskId));
  if (!task) return res.status(404).json({ error: "Task not found" });

  if (req.body.status) task.status = req.body.status;
  if (req.body.actual !== undefined) task.actual = req.body.actual;

  project.updatedAt = new Date().toISOString();
  saveProjects(projects);
  res.json(task);
});

app.delete("/api/projects/:id", (req, res) => {
  const projects = readProjects();
  const id = Number(req.params.id);
  const filtered = projects.filter(p => p.id !== id);

  if (filtered.length === projects.length) {
    return res.status(404).json({ error: "Project not found" });
  }

  saveProjects(filtered);
  res.json({ message: "Project deleted" });
});

app.get("/api/stats", (req, res) => {
  const projects = readProjects();
  const totalTasks = projects.reduce((sum, p) => sum + (p.tasks || []).length, 0);
  const completedTasks = projects.reduce(
    (sum, p) => sum + (p.tasks || []).filter(t => t.status === "Completed").length,
    0
  );
  const delayed = projects.filter(p => p.status === "Delayed").length;
  const average = projects.length
    ? Math.round(projects.reduce((sum, p) => sum + p.progress, 0) / projects.length)
    : 0;

  res.json({
    projects: projects.length,
    averageProgress: average,
    delayed,
    tasks: totalTasks,
    completedTasks
  });
});

app.get("/api/health", (req, res) => {
  res.json({ ok: true, serverTime: new Date().toISOString() });
});

app.get("*", (req, res) => {
  res.sendFile(path.join(__dirname, "public", "index.html"));
});

ensureData();
app.listen(PORT, () => {
  console.log(`InfraTrack running at http://localhost:${PORT}`);
});
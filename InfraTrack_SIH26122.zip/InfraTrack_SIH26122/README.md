# InfraTrack — SIH26122

Simple full-stack prototype for:

**Intelligent Data Capture & Schedule-Linking Layer for Infrastructure Project Management: Real-Time Actual Progress Tracking (Planning-to-Execution Bridge)**

## Technologies

- Frontend: HTML + CSS + JavaScript
- Backend: Node.js + Express
- Storage: JSON file
- Real-time UI: automatic API polling every 3 seconds

No React, database server, or complicated setup is required.

## 1. Install Node.js

Install Node.js from the official Node.js website if it is not already installed.

Check:

```bash
node -v
npm -v
```

## 2. Open the project

Extract this ZIP and open the `InfraTrack_SIH26122` folder in VS Code.

## 3. Install backend package

Open the VS Code terminal:

```bash
npm install
```

## 4. Start the application

```bash
npm start
```

You should see:

```text
InfraTrack running at http://localhost:3000
```

Open:

http://localhost:3000

## Working features

- Live server status and clock
- Dashboard statistics
- Automatic refresh every 3 seconds
- Add project
- Search projects
- Open project details
- Update project progress
- Add project tasks
- Mark tasks completed
- Schedule table
- Delete project
- Reports page
- Download report as TXT
- JSON data persistence

## How the real-time part works

The browser calls `/api/projects` and `/api/stats` every 3 seconds. When another user or browser changes project data through the API, the dashboard refreshes automatically.

For a larger production system, this polling can later be replaced with WebSockets/Socket.IO and the JSON storage can be replaced with MySQL/PostgreSQL.

## API endpoints

GET `/api/projects`

POST `/api/projects`

PATCH `/api/projects/:id/progress`

POST `/api/projects/:id/tasks`

PATCH `/api/projects/:projectId/tasks/:taskId`

DELETE `/api/projects/:id`

GET `/api/stats`

GET `/api/health`
